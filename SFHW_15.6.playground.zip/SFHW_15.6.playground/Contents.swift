import UIKit

// 1
enum NetworkError: Int, Error {
    case error1 = 400
    case error2 = 404
    case error3 = 500
}

var testError = 400

do {
    if testError == 400 {
        throw NetworkError.error1
    }
    if testError == 404 {
        throw NetworkError.error2
    }
    if testError == 500 {
        throw NetworkError.error3
    }
} catch NetworkError.error1 {
    print("Error 400")
}
catch NetworkError.error2 {
    print("Error 404")
}
catch NetworkError.error3 {
    print("Error 500")
}

// 2
func networkTest() throws {
    if testError == 400 {
        throw NetworkError.error1
    }
    if testError == 404 {
        throw NetworkError.error2
    }
    if testError == 500 {
        throw NetworkError.error3
    }
}

do {
    try networkTest()
    
}catch NetworkError.error1 {
    print("Error 400")
}
catch NetworkError.error2 {
    print("Error 404")
}
catch NetworkError.error3 {
    print("Error 500")
}

// 3
func typeCheching<T, F>(a: T, b: F) {
  print(type(of: a) == type(of: b) ? "Yes" : "No")
}

typeCheching(a: 5, b: 4.4)

// 4
enum TypeError: Error {
    case same
    case notSame
}

func typeChechingThrow<T, F>(a: T, b: F) throws {
    if type(of: a) == type(of: b) {
        throw TypeError.same
    }
    
    if type(of: a) != type(of: b) {
        throw TypeError.notSame
    }
}

do {
    try typeChechingThrow(a: 3, b: 9.8)
} catch TypeError.same {
    print("The same")
} catch TypeError.notSame {
    print("Not same")
}

//5
func checkValue<T:Equatable>(a:T, b: T) -> Bool {
   
    a == b ? true : false
}

checkValue(a: 5, b: 3)
